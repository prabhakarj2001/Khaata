KHAATA SCANNER UPGRADE — SETUP

FILES:
- scanner_core.py: indicators, signal classification, backtest and risk levels.
- alerts.py: scheduled runner and Telegram report.
- requirements.txt: Python packages.

INSTALL:
1. Add scanner_core.py to the same GitHub folder as dashboard.py.
2. Replace the existing alerts.py with this package's alerts.py.
3. Update requirements.txt with this package's contents.
4. Keep your existing GitHub Actions workflow if it already runs `python alerts.py`.
   Do not add a second workflow unless you disable the old one.
5. GitHub Actions Secrets must contain TG_TOKEN and TG_CHAT_ID.
6. Never put the Telegram token in a Python file.

CADENCE:
- The existing GitHub workflow determines when the scanner runs.
- Telegram reports are sent on calendar days 1, 4, 7, 10, ... of each month.
- CSV reports are generated on every scheduled run.

SIGNAL RULES:
- STRONG BUY: RSI(14) < 40 and CMF(20) > 0
- WEAK BUY: RSI(14) < 40 and CMF(20) <= 0
- STRONG SELL: price below SMA50 and MACD below its signal line
- WEAK SELL: either the SMA50 breakdown or MACD-down condition
- HOLD: none of the above

RISK:
- Initial stop: entry price minus 2 x ATR(14)
- 2R target: entry + 2 x initial risk
- 3R target: entry + 3 x initial risk

MOMENTUM / DATA:
- 5D return uses exactly five completed trading sessions.
- Volume spike compares current volume with the prior 20 completed sessions.
- 6M and 12M momentum exclude the latest 21 sessions and are adjusted by
  annualized realized volatility.
- In-progress daily candles are excluded before 15:35 IST.
- M&M is included in the stock universe.
- Download failures are listed in the report and failed tickers are skipped.

BACKTEST:
- Historical RSI<40 entries are evaluated at 5, 20 and 60 sessions.
- Summary includes observation count, hit rate, average return, average win/loss,
  payoff ratio and edge versus Nifty 50.
- Live Telegram Buy/Sell signals require at least 100 20-session observations
  and a mean 20-session edge greater than 0.50 percentage points.
- CSV reports: latest_signals.csv, backtest_observations.csv, backtest_summary.csv.

LIMITATIONS:
- Five-year data using today's stock list is survivorship-biased.
- The backtest is an RSI<40 entry study, not a full portfolio simulation.
- Brokerage, taxes, slippage, liquidity and position sizing are not included.
- ATR stop and targets are reference levels, not guaranteed execution prices.
- This is a research scanner, not a validated trading system.
